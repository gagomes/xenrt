"""test import from a builtin module"""

__revision__ = None

from math import log10

def log10_2():
    """bla bla bla"""
    return log10(2)


