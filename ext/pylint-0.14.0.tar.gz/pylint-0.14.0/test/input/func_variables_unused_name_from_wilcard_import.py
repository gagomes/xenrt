"""check unused import from a wildcard import"""
from input.func_w0611 import *
__revision__ = None
