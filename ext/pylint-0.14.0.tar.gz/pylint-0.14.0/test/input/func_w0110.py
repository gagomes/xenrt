"""test too short name
"""

__revision__ = 1

A = None

def a():
    """yo"""
    pass
