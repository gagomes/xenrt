"""check black listed builtins
"""

__revision__ = apply(map, (str, (1, 2, 3)))

YYYYY = map(str, (1, 2, 3))

