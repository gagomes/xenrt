"""test relative import
"""

__revision__ = 0

import func_w0302

if __revision__:
    print func_w0302

