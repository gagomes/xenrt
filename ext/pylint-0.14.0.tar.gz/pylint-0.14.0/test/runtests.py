from logilab.common.testlib import main

if __name__ == '__main__':
    import sys, os
    main(os.path.dirname(sys.argv[0]) or '.')
