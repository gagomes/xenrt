#include "Python.h"
#include "numpy/arrayobject.h"
#include "numpy/ufuncobject.h"
#include "../config.h"

#ifdef HAVE_GAMMA
#define cephesgamma gamma
#endif

/* ========================================================================= */

/* Set up cbrt data */

extern double cbrt(double x);

static void * cbrt_data[] = { (void *)cbrt,  (void *)cbrt,  };
static PyUFuncGenericFunction cbrt_functions[] = { NULL, NULL};
static char cbrt_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char cbrt_doc[] = "Cube root";

/* ========================================================================= */

/* Set up erf data */

extern double erf(double x);

static void * erf_data[] = { (void *)erf,  (void *)erf,  };
static PyUFuncGenericFunction erf_functions[] = { NULL, NULL};
static char erf_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char erf_doc[] = "Error function";

/* ========================================================================= */

/* Set up erfc data */

extern double erfc(double x);

static void * erfc_data[] = { (void *)erfc,  (void *)erfc,  };
static PyUFuncGenericFunction erfc_functions[] = { NULL, NULL};
static char erfc_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char erfc_doc[] = "Complementary error function";


/* ========================================================================= */

/* Set up ndtr data */

extern double ndtr(double x);

static void * ndtr_data[] = { (void *)ndtr,  (void *)ndtr,  };
static PyUFuncGenericFunction ndtr_functions[] = { NULL, NULL};
static char ndtr_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char ndtr_doc[] = "Cumulative standard normal distribution";

/* ========================================================================= */

/* Set up ndtri data */

extern double ndtri(double x);

static void * ndtri_data[] = { (void *)ndtri,  (void *)ndtri,  };
static PyUFuncGenericFunction ndtri_functions[] = { NULL, NULL};
static char ndtri_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char ndtri_doc[] = "Inverse of the cumulative normal distribution";

/* ========================================================================= */

/* Set up dawsn data */

extern double dawsn(double x);

static void * dawsn_data[] = { (void *)dawsn,  (void *)dawsn,  };
static PyUFuncGenericFunction dawsn_functions[] = { NULL, NULL};
static char dawsn_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char dawsn_doc[] = "Dawson's integral";

/* ========================================================================= */

/* Set up gamma data */

extern double cephesgamma(double x);

static void * gamma_data[] = { (void *)cephesgamma,  (void *)cephesgamma,  };
static PyUFuncGenericFunction gamma_functions[] = { NULL, NULL};
static char gamma_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char gamma_doc[] = "Gamma function";

/* ========================================================================= */

/* Set up lgamma data */

extern double lgamma(double x);

static void * lgamma_data[] = { (void *)lgamma,  (void *)lgamma,  };
static PyUFuncGenericFunction lgamma_functions[] = { NULL, NULL};
static char lgamma_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char lgamma_doc[] = "Natural logarithm of gamma function";

/* ========================================================================= */

/* Set up rgamma data  */

extern double rgamma(double x);

static void * rgamma_data[] = { (void *)rgamma,  (void *)rgamma,  };
static PyUFuncGenericFunction rgamma_functions[] = { NULL, NULL};
static char rgamma_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char rgamma_doc[] = "Reciprocal gamma function";

/* ========================================================================= */

/* Set up psi data  */

extern double psi(double x);

static void * psi_data[] = { (void *)psi,  (void *)psi,  };
static PyUFuncGenericFunction psi_functions[] = { NULL, NULL};
static char psi_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char psi_doc[] = "Psi (digamma) function";

/* ========================================================================= */

/* Set up j0 data */

extern double j0(double x);

static void * j0_data[] = { (void *)j0,  (void *)j0,  };
static PyUFuncGenericFunction j0_functions[] = { NULL, NULL};
static char j0_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char j0_doc[] = "Bessel function of order zero";


/* ========================================================================= */

/* Set up y0 data */

extern double y0(double x);

static void * y0_data[] = { (void *)y0,  (void *)y0,  };
static PyUFuncGenericFunction y0_functions[] = { NULL, NULL};
static char y0_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char y0_doc[] = "Bessel function of the second kind, order zero";


/* ========================================================================= */

/* Set up i0 data */

extern double i0(double x);

static void * i0_data[] = { (void *)i0,  (void *)i0,  };
static PyUFuncGenericFunction i0_functions[] = { NULL, NULL};
static char i0_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char i0_doc[] = "Modified Bessel function of order zero";


/* ========================================================================= */

/* Set up i0e data */

extern double i0e(double x);

static void * i0e_data[] = { (void *)i0e,  (void *)i0e,  };
static PyUFuncGenericFunction i0e_functions[] = { NULL, NULL};
static char i0e_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char i0e_doc[] =
  "Modified Bessel function of order zero, exponentially scaled";


/* ========================================================================= */

/* Set up k0 data */

extern double k0(double x);

static void * k0_data[] = { (void *)k0,  (void *)k0,  };
static PyUFuncGenericFunction k0_functions[] = { NULL, NULL};
static char k0_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char k0_doc[] = "Modified Bessel function, third kind, order zero";


/* ========================================================================= */

/* Set up k0e data */

extern double k0e(double x);

static void * k0e_data[] = { (void *)k0e,  (void *)k0e,  };
static PyUFuncGenericFunction k0e_functions[] = { NULL, NULL};
static char k0e_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char k0e_doc[] =
  "Modified Bessel function, third kind, order zero, exponentially scaled";


/* ========================================================================= */

/* Set up j1 data */

extern double j1(double x);

static void * j1_data[] = { (void *)j1,  (void *)j1,  };
static PyUFuncGenericFunction j1_functions[] = { NULL, NULL};
static char j1_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char j1_doc[] = "Bessel function of order one";


/* ========================================================================= */

/* Set up y1 data */

extern double y1(double x);

static void * y1_data[] = { (void *)y1,  (void *)y1,  };
static PyUFuncGenericFunction y1_functions[] = { NULL, NULL};
static char y1_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char y1_doc[] = "Bessel function of the second kind, order one";


/* ========================================================================= */

/* Set up i1 data */

extern double i1(double x);

static void * i1_data[] = { (void *)i1,  (void *)i1,  };
static PyUFuncGenericFunction i1_functions[] = { NULL, NULL};
static char i1_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char i1_doc[] = "Modified Bessel function of order one";


/* ========================================================================= */

/* Set up i1e data */

extern double i1e(double x);

static void * i1e_data[] = { (void *)i1e,  (void *)i1e,  };
static PyUFuncGenericFunction i1e_functions[] = { NULL, NULL};
static char i1e_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char i1e_doc[] =
  "Modified Bessel function of order one, exponentially scaled";


/* ========================================================================= */

/* Set up k1 data */

extern double k1(double x);

static void * k1_data[] = { (void *)k1,  (void *)k1,  };
static PyUFuncGenericFunction k1_functions[] = { NULL, NULL};
static char k1_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char k1_doc[] = "Modified Bessel function, third kind, order one";


/* ========================================================================= */

/* Set up k1e data */

extern double k1e(double x);

static void * k1e_data[] = { (void *)k1e,  (void *)k1e,  };
static PyUFuncGenericFunction k1e_functions[] = { NULL, NULL};
static char k1e_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char k1e_doc[] =
  "Modified Bessel function, third kind, order one, exponentially scaled";

/* ========================================================================= */

/* Set up ellpe data */

extern double ellpe(double x);

static void * ellpe_data[] = { (void *)ellpe,  (void *)ellpe,  };
static PyUFuncGenericFunction ellpe_functions[] = { NULL, NULL};
static char ellpe_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char ellpe_doc[] =
  "Complete elliptic integral of the second kind";

/* ========================================================================= */

/* Set up ellpk data */

extern double ellpk(double m1);

static void * ellpk_data[] = { (void *)ellpk,  (void *)ellpk,  };
static PyUFuncGenericFunction ellpk_functions[] = { NULL, NULL};
static char ellpk_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char ellpk_doc[] =
  "Complete elliptic integral of the first kind";

/* ========================================================================= */

/* Set up spence data */

extern double spence(double x);

static void * spence_data[] = { (void *)spence,  (void *)spence,  };
static PyUFuncGenericFunction spence_functions[] = { NULL, NULL};
static char spence_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char spence_doc[] = "Dilogarithm";

/* ========================================================================= */

/* Set up zetac data */

extern double zetac(double x);

static void * zetac_data[] = { (void *)zetac,  (void *)zetac,  };
static PyUFuncGenericFunction zetac_functions[] = { NULL, NULL};
static char zetac_signatures[] =
  {PyArray_FLOAT, PyArray_FLOAT, PyArray_DOUBLE, PyArray_DOUBLE};
static char zetac_doc[] = "Riemann zeta function";

/* ========================================================================= */

/* fac */

extern double fac(int i);

static char fac__doc__[] = "Factorial function";

static PyObject* transcendental_fac (PyObject* unused, PyObject* args)
{ double result;
  int i;
  if(!PyArg_ParseTuple(args, "i", &i)) return NULL;
  result = fac(i);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* bdtr */

extern double bdtr(int k, int n, double p);

static char bdtr__doc__[] = "Cumulative binomial probability density";

static PyObject* transcendental_bdtr (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double p;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &p)) return NULL;
  result = bdtr(k, n, p);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* bdtrc */

extern double bdtrc(int k, int n, double p);

static char bdtrc__doc__[] = "Complemented binomial distribution";

static PyObject* transcendental_bdtrc (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double p;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &p)) return NULL;
  result = bdtrc(k, n, p);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* bdtri */

extern double bdtri(int k, int n, double y);

static char bdtri__doc__[] = "Inverse binomial distribution";

static PyObject* transcendental_bdtri (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double y;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &y)) return NULL;
  result = bdtri(k, n, y);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* nbdtr */

extern double nbdtr(int k, int n, double p);

static char nbdtr__doc__[] = "Cumulative negative binomial probability density";

static PyObject* transcendental_nbdtr (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double p;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &p)) return NULL;
  result = nbdtr(k, n, p);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* nbdtrc */

extern double nbdtrc(int k, int n, double p);

static char nbdtrc__doc__[] =
"Complemented cumulative negative binomial distribution";

static PyObject* transcendental_nbdtrc (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double p;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &p)) return NULL;
  result = nbdtrc(k, n, p);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* nbdtri */

extern double nbdtri(int k, int n, double p);

static char nbdtri__doc__[] =
"Inverse of the cumulative negative binomial distribution";

static PyObject* transcendental_nbdtri (PyObject* unused, PyObject* args)
{ double result;
  int k;
  int n;
  double y;
  if(!PyArg_ParseTuple(args, "iid", &k, &n, &y)) return NULL;
  result = nbdtri(k, n, y);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* gdtr */

extern double gdtr(double a, double b, double x);

static char gdtr__doc__[] = "Cumulative gamma probability density";

static PyObject* transcendental_gdtr (PyObject* unused, PyObject* args)
{ double result;
  double a;
  double b;
  double x;
  if(!PyArg_ParseTuple(args, "ddd", &a, &b, &x)) return NULL;
  result = gdtr(a, b, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* gdtrc */

static char gdtrc__doc__[] =
"Complemented cumulative gamma distribution function";

extern double gdtrc(double a, double b, double x);

static PyObject* transcendental_gdtrc (PyObject* unused, PyObject* args)
{ double result;
  double a;
  double b;
  double x;
  if(!PyArg_ParseTuple(args, "ddd", &a, &b, &x)) return NULL;
  result = gdtrc(a, b, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* pdtr */

static char pdtr__doc__[] = "Cumulative Poisson distribution";

extern double pdtr(int k, double m);

static PyObject* transcendental_pdtr (PyObject* unused, PyObject* args)
{ double result;
  int k;
  double m;
  if(!PyArg_ParseTuple(args, "id", &k, &m)) return NULL;
  result = pdtr(k, m);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* pdtrc */

static char pdtrc__doc__[] = "Complemented cumulative Poisson distribution";

extern double pdtrc(int k, double m);

static PyObject* transcendental_pdtrc (PyObject* unused, PyObject* args)
{ double result;
  int k;
  double m;
  if(!PyArg_ParseTuple(args, "id", &k, &m)) return NULL;
  result = pdtrc(k, m);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* pdtri */

static char pdtri__doc__[] = "Inverse of the cumulative Poisson distribution";

extern double pdtri(int k, double y);

static PyObject* transcendental_pdtri (PyObject* unused, PyObject* args)
{ double result;
  int k;
  double y;
  if(!PyArg_ParseTuple(args, "id", &k, &y)) return NULL;
  result = pdtri(k, y);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* beta */

static char beta__doc__[] = "Beta function";

extern double beta(double a, double b);

static PyObject* transcendental_beta (PyObject* unused, PyObject* args)
{ double result;
  double a;
  double b;
  if(!PyArg_ParseTuple(args, "dd", &a, &b)) return NULL;
  result = beta(a, b);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* igam */

static char igam__doc__[] = "Incomplete gamma integral";

extern double igam(double a, double x);

static PyObject* transcendental_igam (PyObject* unused, PyObject* args)
{ double result;
  double x;
  double a;
  if(!PyArg_ParseTuple(args, "dd", &a, &x)) return NULL;
  result = igam(a, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* igamc */

static char igamc__doc__[] = "Complemented incomplete gamma integral";

extern double igamc(double a, double x);

static PyObject* transcendental_igamc (PyObject* unused, PyObject* args)
{ double result;
  double x;
  double a;
  if(!PyArg_ParseTuple(args, "dd", &a, &x)) return NULL;
  result = igamc(a, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* igami */

static char igami__doc__[] =
"Inverse of the complemented incomplete gamma integral";

extern double igami(double a, double p);

static PyObject* transcendental_igami (PyObject* unused, PyObject* args)
{ double result;
  double p;
  double a;
  if(!PyArg_ParseTuple(args, "dd", &a, &p)) return NULL;
  result = igami(a, p);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* incbet */

static char incbet__doc__[] = "Incomplete beta integral";

extern double incbet(double a, double b, double x);

static PyObject* transcendental_incbet (PyObject* unused, PyObject* args)
{ double result;
  double a;
  double b;
  double x;
  if(!PyArg_ParseTuple(args, "ddd", &a, &b, &x)) return NULL;
  result = incbet(a, b, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* incbi */

static char incbi__doc__[] = "Inverse of the incomplete beta integral";

extern double incbi(double a, double b, double y);

static PyObject* transcendental_incbi (PyObject* unused, PyObject* args)
{ double result;
  double a;
  double b;
  double y;
  if(!PyArg_ParseTuple(args, "ddd", &a, &b, &y)) return NULL;
  result = incbi(a, b, y);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* fresnl */

static char fresnl__doc__[] = "Fresnel cosine and sine integrals";

extern double fresnl(double x, double* c, double* s);

static PyObject* transcendental_fresnl (PyObject* unused, PyObject* args)
{ double s;
  double c;
  double x;
  if(!PyArg_ParseTuple(args, "d", &x)) return NULL;
  fresnl(x, &s, &c);
  return Py_BuildValue("dd", s, c);
}

/* ========================================================================= */

/* stdtr */

static char stdtr__doc__[] = "Cumulative Student's t distribution";

extern double stdtr(int k, double t);

static PyObject* transcendental_stdtr (PyObject* unused, PyObject* args)
{ double result;
  double t;
  int k;
  if(!PyArg_ParseTuple(args, "id", &k, &t)) return NULL;
  result = stdtr(k, t);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* stdtri */

static char stdtri__doc__[] =
"Inverse of the cumulative Student's t distribution";

extern double stdtri(int k, double t);

static PyObject* transcendental_stdtri (PyObject* unused, PyObject* args)
{ double result;
  double t;
  int k;
  if(!PyArg_ParseTuple(args, "id", &k, &t)) return NULL;
  result = stdtri(k, t);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* chdtr */

static char chdtr__doc__[] = "Cumulative chi square distribution";

extern double chdtr(double nu, double x);

static PyObject* transcendental_chdtr (PyObject* unused, PyObject* args)
{ double result;
  double x;
  double nu;
  if(!PyArg_ParseTuple(args, "dd", &nu, &x)) return NULL;
  result = chdtr(nu, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* chdtrc */

static char chdtrc__doc__[] = "Complemented cumulative chi square distribution";

extern double chdtrc(double nu, double x);

static PyObject* transcendental_chdtrc (PyObject* unused, PyObject* args)
{ double result;
  double x;
  double nu;
  if(!PyArg_ParseTuple(args, "dd", &nu, &x)) return NULL;
  result = chdtrc(nu, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* chdtri */

static char chdtri__doc__[] =
"Inverse of the complemented cumulative chi square distribution.";

extern double chdtri(double nu, double y);

static PyObject* transcendental_chdtri (PyObject* unused, PyObject* args)
{ double result;
  double y;
  double nu;
  if(!PyArg_ParseTuple(args, "dd", &nu, &y)) return NULL;
  result = chdtri(nu, y);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* fdtr */

static char fdtr__doc__[] = "Cumulative F distribution";

extern double fdtr(int nu1, int nu2, double x);

static PyObject* transcendental_fdtr (PyObject* unused, PyObject* args)
{ double result;
  double x;
  int nu1, nu2;
  if(!PyArg_ParseTuple(args, "iid", &nu1, &nu2, &x)) return NULL;
  result = fdtr(nu1, nu2, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* fdtrc */

static char fdtrc__doc__[] = "Complemented cumulative F distribution";

extern double fdtrc(int nu1, int nu2, double x);

static PyObject* transcendental_fdtrc (PyObject* unused, PyObject* args)
{ double result;
  double x;
  int nu1, nu2;
  if(!PyArg_ParseTuple(args, "iid", &nu1, &nu2, &x)) return NULL;
  result = fdtrc(nu1, nu2, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* fdtri */

static char fdtri__doc__[] =
"Inverse of the complemented cumulative F distribution";

extern double fdtri(int nu1, int nu2, double x);

static PyObject* transcendental_fdtri (PyObject* unused, PyObject* args)
{ double result;
  double x;
  int nu1, nu2;
  if(!PyArg_ParseTuple(args, "iid", &nu1, &nu2, &x)) return NULL;
  result = fdtri(nu1, nu2, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* jn */

static char jn__doc__[] = "Bessel function of integer order";

extern double jn(int n,  double x);

static PyObject* transcendental_jn (PyObject* unused, PyObject* args)
{ double result;
  int n;
  double x;
  if(!PyArg_ParseTuple(args, "id", &n, &x)) return NULL;
  result = jn(n, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* jv */

static char jv__doc__[] = "Bessel function of noninteger order";

extern double jv(double v,  double x);

static PyObject* transcendental_jv (PyObject* unused, PyObject* args)
{ double result;
  double v;
  double x;
  if(!PyArg_ParseTuple(args, "dd", &v, &x)) return NULL;
  result = jv(v, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* yn */

static char yn__doc__[] = "Bessel function of second kind of integer order";

extern double yn(int n,  double x);

static PyObject* transcendental_yn (PyObject* unused, PyObject* args)
{ double result;
  int n;
  double x;
  if(!PyArg_ParseTuple(args, "id", &n, &x)) return NULL;
  result = yn(n, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* yv */

static char yv__doc__[] = "Bessel function of second kind of noninteger order";

extern double yv(double v,  double x);

static PyObject* transcendental_yv (PyObject* unused, PyObject* args)
{ double result;
  double v;
  double x;
  if(!PyArg_ParseTuple(args, "dd", &v, &x)) return NULL;
  result = yv(v, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* iv */

static char iv__doc__[] = "Modified Bessel function of noninteger order";

extern double iv(double v,  double x);

static PyObject* transcendental_iv (PyObject* unused, PyObject* args)
{ double result;
  double v;
  double x;
  if(!PyArg_ParseTuple(args, "dd", &v, &x)) return NULL;
  result = iv(v, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* kn */

static char kn__doc__[] =
  "Modified Bessel function, third kind, integer order";

extern double kn(int n,  double x);

static PyObject* transcendental_kn (PyObject* unused, PyObject* args)
{ double result;
  int n;
  double x;
  if(!PyArg_ParseTuple(args, "id", &n, &x)) return NULL;
  result = kn(n, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* airy */

static char airy__doc__[] = "Airy function";

extern int airy(double x, double* ai, double* aip, double* bi, double* bip);

static PyObject* transcendental_airy (PyObject* unused, PyObject* args)
{ int errorcode;
  double x;
  double ai, aip, bi, bip;
  if(!PyArg_ParseTuple(args, "d", &x)) return NULL;
  errorcode = airy(x,&ai,&aip,&bi,&bip);
  if (errorcode<0)
  { PyObject* error =
      PyString_FromString("WARNING: Argument larger than MAXAIRY in airy\n");
    if (error!=NULL)
    { PyObject_Print(error, stdout, Py_PRINT_RAW);
      Py_DECREF(error);
    }
  }
  return Py_BuildValue("dddd", ai, aip, bi, bip);
}

/* ======================================================================== */

/* expn */

static char expn__doc__[] = "Exponential integral En";

extern double expn(int n,  double x);

static PyObject* transcendental_expn (PyObject* unused, PyObject* args)
{ double result;
  int n;
  double x;
  if(!PyArg_ParseTuple(args, "id", &n, &x)) return NULL;
  result = expn(n, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* shichi */

static char shichi__doc__[] = "Hyperbolic sine and cosine integrals";

extern int shichi(double x, double* Chi, double* Shi);

static PyObject* transcendental_shichi (PyObject* unused, PyObject* args)
{ double x;
  double Chi, Shi;
  if(!PyArg_ParseTuple(args, "d", &x)) return NULL;
  shichi(x,&Chi,&Shi);
  return Py_BuildValue("dd", Chi, Shi);
}

/* ======================================================================== */

/* sici */

static char sici__doc__[] = "Sine and cosine integrals";

extern int sici(double x, double* Si, double* Ci);

static PyObject* transcendental_sici (PyObject* unused, PyObject* args)
{ double x;
  double Ci, Si;
  if(!PyArg_ParseTuple(args, "d", &x)) return NULL;
  sici(x,&Ci,&Si);
  return Py_BuildValue("dd", Ci, Si);
}

/* ========================================================================= */

/* hyperg */

extern double hyperg(double a, double b, double x);

static char hyperg__doc__[] = "Confluent hypergeometric function";

static PyObject* transcendental_hyperg (PyObject* unused, PyObject* args)
{ double result;
  double a, b, x;
  if(!PyArg_ParseTuple(args, "ddd", &a, &b, &x)) return NULL;
  result = hyperg(a, b, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* hyp2f1 */

extern double hyp2f1(double a, double b, double c, double x);

static char hyp2f1__doc__[] = "Gauss hypergeometric function";

static PyObject* transcendental_hyp2f1 (PyObject* unused, PyObject* args)
{ double result;
  double a, b, c, x;
  if(!PyArg_ParseTuple(args, "dddd", &a, &b, &c, &x)) return NULL;
  result = hyp2f1(a, b, c, x);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* ellik */

extern double ellik(double phi, double m);

static char ellik__doc__[] = "Incomplete elliptic integral of the first kind";

static PyObject* transcendental_ellik (PyObject* unused, PyObject* args)
{ double result;
  double phi, m;
  if(!PyArg_ParseTuple(args, "dd", &phi, &m)) return NULL;
  result = ellik(phi, m);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* ellie */

extern double ellie(double phi, double m);

static char ellie__doc__[] = "Incomplete elliptic integral of the second kind";

static PyObject* transcendental_ellie (PyObject* unused, PyObject* args)
{ double result;
  double phi, m;
  if(!PyArg_ParseTuple(args, "dd", &phi, &m)) return NULL;
  result = ellie(phi, m);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */

/* ellpj */

static char ellpj__doc__[] = "Jacobian Elliptic Functions";

extern int ellpj(double x, double m,
                 double* sn, double* cn, double* dn, double* phi);

static PyObject* transcendental_ellpj (PyObject* unused, PyObject* args)
{ int errorcode;
  double u, m;
  double sn, cn, dn, phi;
  if(!PyArg_ParseTuple(args, "dd", &u, &m)) return NULL;
  errorcode = ellpj(u,m,&sn,&cn,&dn,&phi);
  if (errorcode<0)
  { PyObject* error =
      PyString_FromString("WARNING: Error occurred in ellpj\n");
    if (error!=NULL)
    { PyObject_Print(error, stdout, Py_PRINT_RAW);
      Py_DECREF(error);
    }
  }
  return Py_BuildValue("dddd", sn, cn, dn, phi);
}

/* ========================================================================= */

/* zeta */

extern double zeta(double x, double q);

static char zeta__doc__[] = "Riemann zeta function of two arguments";

static PyObject* transcendental_zeta (PyObject* unused, PyObject* args)
{ double result;
  double x, q;
  if(!PyArg_ParseTuple(args, "dd", &x, &q)) return NULL;
  result = zeta(x, q);
  return Py_BuildValue("d",result);
}

/* ========================================================================= */

/* struve */

extern double struve(double v, double x);

static char struve__doc__[] = "Struve function";

static PyObject* transcendental_struve (PyObject* unused, PyObject* args)
{ double result;
  double v, x;
  if(!PyArg_ParseTuple(args, "dd", &v, &x)) return NULL;
  result = struve(v, x);
  return Py_BuildValue("d",result);
}

/* ======================================================================== */
/* ======================================================================== */
/* Methods table                                                            */
/* ======================================================================== */
/* ======================================================================== */

static struct PyMethodDef methods[] =
{ {"fdtr", (PyCFunction) transcendental_fdtr, METH_VARARGS, fdtr__doc__},
  {"fdtrc", (PyCFunction) transcendental_fdtrc, METH_VARARGS, fdtrc__doc__},
  {"fdtri", (PyCFunction) transcendental_fdtri, METH_VARARGS, fdtri__doc__},
  {"chdtr", (PyCFunction) transcendental_chdtr, METH_VARARGS, chdtr__doc__},
  {"chdtrc", (PyCFunction) transcendental_chdtrc, METH_VARARGS, chdtrc__doc__},
  {"chdtri", (PyCFunction) transcendental_chdtri, METH_VARARGS, chdtri__doc__},
  {"pdtr", (PyCFunction) transcendental_pdtr, METH_VARARGS, pdtr__doc__},
  {"pdtrc", (PyCFunction) transcendental_pdtrc, METH_VARARGS, pdtrc__doc__},
  {"pdtri", (PyCFunction) transcendental_pdtri, METH_VARARGS, pdtri__doc__},
  {"bdtr", (PyCFunction) transcendental_bdtr, METH_VARARGS, bdtr__doc__},
  {"bdtrc", (PyCFunction) transcendental_bdtrc, METH_VARARGS, bdtrc__doc__},
  {"bdtri", (PyCFunction) transcendental_bdtri, METH_VARARGS, bdtri__doc__},
  {"nbdtr", (PyCFunction) transcendental_nbdtr, METH_VARARGS, nbdtr__doc__},
  {"nbdtrc", (PyCFunction) transcendental_nbdtrc, METH_VARARGS, nbdtrc__doc__},
  {"nbdtri", (PyCFunction) transcendental_nbdtri, METH_VARARGS, nbdtri__doc__},
  {"gdtr", (PyCFunction) transcendental_gdtr, METH_VARARGS, gdtr__doc__},
  {"gdtrc", (PyCFunction) transcendental_gdtrc, METH_VARARGS, gdtrc__doc__},
  {"stdtr", (PyCFunction) transcendental_stdtr, METH_VARARGS, stdtr__doc__},
  {"stdtri", (PyCFunction) transcendental_stdtri, METH_VARARGS, stdtri__doc__},
  {"fac", (PyCFunction) transcendental_fac, METH_VARARGS, fac__doc__},
  {"beta", (PyCFunction) transcendental_beta, METH_VARARGS, beta__doc__},
  {"igam", (PyCFunction) transcendental_igam, METH_VARARGS, igam__doc__},
  {"igamc", (PyCFunction) transcendental_igamc, METH_VARARGS, igamc__doc__},
  {"igami", (PyCFunction) transcendental_igami, METH_VARARGS, igami__doc__},
  {"incbet", (PyCFunction) transcendental_incbet, METH_VARARGS, incbet__doc__},
  {"incbi", (PyCFunction) transcendental_incbi, METH_VARARGS, incbi__doc__},
  {"fresnl", (PyCFunction) transcendental_fresnl, METH_VARARGS, fresnl__doc__},
  {"jn", (PyCFunction) transcendental_jn, METH_VARARGS, jn__doc__},
  {"jv", (PyCFunction) transcendental_jv, METH_VARARGS, jv__doc__},
  {"yn", (PyCFunction) transcendental_yn, METH_VARARGS, yn__doc__},
  {"yv", (PyCFunction) transcendental_yv, METH_VARARGS, yv__doc__},
  {"iv", (PyCFunction) transcendental_iv, METH_VARARGS, iv__doc__},
  {"kn", (PyCFunction) transcendental_kn, METH_VARARGS, kn__doc__},
  {"airy", (PyCFunction) transcendental_airy, METH_VARARGS, airy__doc__},
  {"expn", (PyCFunction) transcendental_expn, METH_VARARGS, expn__doc__},
  {"shichi", (PyCFunction) transcendental_shichi, METH_VARARGS, shichi__doc__},
  {"sici", (PyCFunction) transcendental_sici, METH_VARARGS, sici__doc__},
  {"hyperg", (PyCFunction) transcendental_hyperg, METH_VARARGS, hyperg__doc__},
  {"hyp2f1", (PyCFunction) transcendental_hyp2f1, METH_VARARGS, hyp2f1__doc__},
  {"ellik", (PyCFunction) transcendental_ellik, METH_VARARGS, ellik__doc__},
  {"ellie", (PyCFunction) transcendental_ellie, METH_VARARGS, ellie__doc__},
  {"ellpj", (PyCFunction) transcendental_ellpj, METH_VARARGS, ellpj__doc__},
  {"zeta", (PyCFunction) transcendental_zeta, METH_VARARGS, zeta__doc__},
  {"struve", (PyCFunction) transcendental_struve, METH_VARARGS, struve__doc__},
  {NULL, NULL, 0, NULL}
};

/* ========================================================================= */

#if defined(INFINITY) || defined(HUGE_VAL)
extern double CEPHESINFINITY;
#endif

static char transcendental_module_documentation[] =
"Transcendental functions for Python";

void init_transcendental(void) {
  PyObject *m, *d, *f;

  /* Import the array and ufunc objects */
  import_array();
  import_ufunc();

  /* CEPHESINFINITY has to be set inside a function if HUGE_VAL is used */ 
#ifdef INFINITY
  CEPHESINFINITY = INFINITY;
#else
#ifdef HUGE_VAL
  CEPHESINFINITY = HUGE_VAL;
#endif
#endif
 
  /* Create the module and add the functions */
  m = Py_InitModule4("_transcendental",
                     methods,
		     transcendental_module_documentation,
		     (PyObject*)NULL,
		     PYTHON_API_VERSION); 
  d = PyModule_GetDict(m);

  cbrt_functions[0] = PyUFunc_f_f_As_d_d;
  cbrt_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(cbrt_functions,
                              cbrt_data,
                              cbrt_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "cbrt", cbrt_doc, 1);
  PyDict_SetItemString(d, "cbrt", f);
  Py_DECREF(f);

  erf_functions[0] = PyUFunc_f_f_As_d_d;
  erf_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(erf_functions,
                              erf_data,
                              erf_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "erf", erf_doc, 1);
  PyDict_SetItemString(d, "erf", f);
  Py_DECREF(f);

  erfc_functions[0] = PyUFunc_f_f_As_d_d;
  erfc_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(erfc_functions,
                              erfc_data,
                              erfc_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "erfc", erfc_doc, 1);
  PyDict_SetItemString(d, "erfc", f);
  Py_DECREF(f);

  ndtr_functions[0] = PyUFunc_f_f_As_d_d;
  ndtr_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(ndtr_functions,
                              ndtr_data,
                              ndtr_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "ndtr", ndtr_doc, 1);
  PyDict_SetItemString(d, "ndtr", f);
  Py_DECREF(f);

  ndtri_functions[0] = PyUFunc_f_f_As_d_d;
  ndtri_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(ndtri_functions,
                              ndtri_data,
                              ndtri_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "ndtri", ndtri_doc, 1);
  PyDict_SetItemString(d, "ndtri", f);
  Py_DECREF(f);

  dawsn_functions[0] = PyUFunc_f_f_As_d_d;
  dawsn_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(dawsn_functions,
                              dawsn_data,
                              dawsn_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "dawsn", dawsn_doc, 1);
  PyDict_SetItemString(d, "dawsn", f);
  Py_DECREF(f);

  gamma_functions[0] = PyUFunc_f_f_As_d_d;
  gamma_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(gamma_functions,
                              gamma_data,
                              gamma_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "gamma", gamma_doc, 1);
  PyDict_SetItemString(d, "gamma", f);
  Py_DECREF(f);

  lgamma_functions[0] = PyUFunc_f_f_As_d_d;
  lgamma_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(lgamma_functions,
                              lgamma_data,
                              lgamma_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "lgamma", lgamma_doc, 1);
  PyDict_SetItemString(d, "lgamma", f);
  Py_DECREF(f);

  rgamma_functions[0] = PyUFunc_f_f_As_d_d;
  rgamma_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(rgamma_functions,
                              rgamma_data,
                              rgamma_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "rgamma", rgamma_doc, 1);
  PyDict_SetItemString(d, "rgamma", f);
  Py_DECREF(f);

  psi_functions[0] = PyUFunc_f_f_As_d_d;
  psi_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(psi_functions,
                              psi_data,
                              psi_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "psi", psi_doc, 1);
  PyDict_SetItemString(d, "psi", f);
  Py_DECREF(f);

  j0_functions[0] = PyUFunc_f_f_As_d_d;
  j0_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(j0_functions,
                              j0_data,
                              j0_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "j0", j0_doc, 1);
  PyDict_SetItemString(d, "j0", f);
  Py_DECREF(f);

  y0_functions[0] = PyUFunc_f_f_As_d_d;
  y0_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(y0_functions,
                              y0_data,
                              y0_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "y0", y0_doc, 1);
  PyDict_SetItemString(d, "y0", f);
  Py_DECREF(f);

  i0_functions[0] = PyUFunc_f_f_As_d_d;
  i0_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(i0_functions,
                              i0_data,
                              i0_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "i0", i0_doc, 1);
  PyDict_SetItemString(d, "i0", f);
  Py_DECREF(f);

  i0e_functions[0] = PyUFunc_f_f_As_d_d;
  i0e_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(i0e_functions,
                              i0e_data,
                              i0e_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "i0e", i0e_doc, 1);
  PyDict_SetItemString(d, "i0e", f);
  Py_DECREF(f);

  k0_functions[0] = PyUFunc_f_f_As_d_d;
  k0_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(k0_functions,
                              k0_data,
                              k0_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "k0", k0_doc, 1);
  PyDict_SetItemString(d, "k0", f);
  Py_DECREF(f);

  k0e_functions[0] = PyUFunc_f_f_As_d_d;
  k0e_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(k0e_functions,
                              k0e_data,
                              k0e_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "k0e", k0e_doc, 1);
  PyDict_SetItemString(d, "k0e", f);
  Py_DECREF(f);

  j1_functions[0] = PyUFunc_f_f_As_d_d;
  j1_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(j1_functions,
                              j1_data,
                              j1_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "j1", j1_doc, 1);
  PyDict_SetItemString(d, "j1", f);
  Py_DECREF(f);

  y1_functions[0] = PyUFunc_f_f_As_d_d;
  y1_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(y1_functions,
                              y1_data,
                              y1_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "y1", y1_doc, 1);
  PyDict_SetItemString(d, "y1", f);
  Py_DECREF(f);

  i1_functions[0] = PyUFunc_f_f_As_d_d;
  i1_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(i1_functions,
                              i1_data,
                              i1_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "i1", i1_doc, 1);
  PyDict_SetItemString(d, "i1", f);
  Py_DECREF(f);

  i1e_functions[0] = PyUFunc_f_f_As_d_d;
  i1e_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(i1e_functions,
                              i1e_data,
                              i1e_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "i1e", i1e_doc, 1);
  PyDict_SetItemString(d, "i1e", f);
  Py_DECREF(f);

  k1_functions[0] = PyUFunc_f_f_As_d_d;
  k1_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(k1_functions,
                              k1_data,
                              k1_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "k1", k1_doc, 1);
  PyDict_SetItemString(d, "k1", f);
  Py_DECREF(f);

  k1e_functions[0] = PyUFunc_f_f_As_d_d;
  k1e_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(k1e_functions,
                              k1e_data,
                              k1e_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "k1e", k1e_doc, 1);
  PyDict_SetItemString(d, "k1e", f);
  Py_DECREF(f);

  ellpe_functions[0] = PyUFunc_f_f_As_d_d;
  ellpe_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(ellpe_functions,
                              ellpe_data,
                              ellpe_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "ellpe", ellpe_doc, 1);
  PyDict_SetItemString(d, "ellpe", f);
  Py_DECREF(f);

  ellpk_functions[0] = PyUFunc_f_f_As_d_d;
  ellpk_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(ellpk_functions,
                              ellpk_data,
                              ellpk_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "ellpk", ellpk_doc, 1);
  PyDict_SetItemString(d, "ellpk", f);
  Py_DECREF(f);

  spence_functions[0] = PyUFunc_f_f_As_d_d;
  spence_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(spence_functions,
                              spence_data,
                              spence_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "spence", spence_doc, 1);
  PyDict_SetItemString(d, "spence", f);
  Py_DECREF(f);

  zetac_functions[0] = PyUFunc_f_f_As_d_d;
  zetac_functions[1] = PyUFunc_d_d;
  f = PyUFunc_FromFuncAndData(zetac_functions,
                              zetac_data,
                              zetac_signatures, 
                              2, 1, 1, PyUFunc_None,
		              "zetac", zetac_doc, 1);
  PyDict_SetItemString(d, "zetac", f);
  Py_DECREF(f);

  /* Check for errors */
  if (PyErr_Occurred())
    Py_FatalError("can't initialize module _transcendental");
}


